/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author admin
 */
public class A {
    public void m(){
        System.out.println("actual business logic");
    } 
}
